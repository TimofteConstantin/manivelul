
public class LeftStrategy implements AlignStrategy 
{

	public LeftStrategy() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void print(String text) 
	{
		System.out.println("+++" + text);
	}
}


public class RightStrategy implements AlignStrategy
{

	public RightStrategy() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void print(String text) 
	{
		System.out.println(text + "+++");
	}
}
